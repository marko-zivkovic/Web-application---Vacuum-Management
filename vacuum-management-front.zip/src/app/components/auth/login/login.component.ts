// login.component.ts

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth.service';
import {FormsModule} from "@angular/forms";
import {NgOptimizedImage} from "@angular/common";
import {InputFieldComponent} from "../../../shared/input-field/input-field.component";
import {ButtonComponent} from "../../../shared/button/button.component";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  imports: [
    FormsModule,
    NgOptimizedImage,
    InputFieldComponent,
    ButtonComponent
  ],
  standalone: true
})
export class LoginComponent {
  username: string = 'admin';
  password: string = 'asd';
  constructor(private authService: AuthService, private router: Router) {}

  login(): void {
    // Clear any existing token before logging in
    localStorage.removeItem('token');

    this.authService.login(this.username, this.password)
      .subscribe({
        next: (token) => {
          this.router.navigate(['/users']).then(r => localStorage.setItem('token', token)); // Navigate to the users page after successful login
        },
        error: (error) => {
          console.error('Login failed:', error);
        }
      });
  }

}
