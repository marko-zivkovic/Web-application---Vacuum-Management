import { Component, OnInit } from '@angular/core';
import { VacuumService } from '../../services/vacuum/vacuum.service';
import { Vacuum } from '../../services/vacuum/vacuum.model';
import { FormsModule } from "@angular/forms";
import { NgForOf } from "@angular/common";
import { TableComponent } from "../../shared/table/table.component";
import {InputFieldComponent} from "../../shared/input-field/input-field.component";
import {ButtonComponent} from "../../shared/button/button.component";
import {SelectComponent} from "../../shared/select/select.component";
import {AddVacuumComponent} from "../add-vacuum/add-vacuum.component";

@Component({
  selector: 'app-search-vacuums',
  standalone: true,
  imports: [
    FormsModule,
    NgForOf,
    TableComponent,
    InputFieldComponent,
    ButtonComponent,
    SelectComponent,
    AddVacuumComponent
  ],
  templateUrl: './search-vacuums.component.html',
  styleUrls: ['./search-vacuums.component.css']
})
export class SearchVacuumsComponent implements OnInit {
  searchParams: any = {
    name: '',
    status: [],
    dateFrom: '',
    dateTo: ''
  };
  vacuums: Vacuum[] = [];
  newVacuum: Partial<Vacuum> = {};

  columns: { key: keyof Vacuum; label: string }[] = [
    { key: 'name', label: 'Name' },
    { key: 'type', label: 'Type' },
    { key: 'description', label: 'Description' },
    { key: 'status', label: 'Status' },
    { key: 'active', label: 'Active' }
  ];

  actions = [
    {
      label: 'Start',
      handler: (item: Vacuum) => this.startVacuum(item.id),
      visible: (item: Vacuum) => true, // Update this based on your role check
    },
    {
      label: 'Stop',
      handler: (item: Vacuum) => this.stopVacuum(item.id),
      visible: (item: Vacuum) => true, // Update this based on your role check
    },
    {
      label: 'Discharge',
      handler: (item: Vacuum) => this.dischargeVacuum(item.id),
      visible: (item: Vacuum) => true, // Update this based on your role check
    },
    {
      label: 'Delete',
      handler: (item: Vacuum) => this.deleteVacuum(item.id),
      visible: (item: Vacuum) => true, // Update this based on your role check
    }
  ];

  constructor(private vacuumService: VacuumService) {}

  ngOnInit(): void {
    this.searchVacuums();
  }

  // Search vacuums
  searchVacuums(): void {
    this.vacuumService.searchVacuums(this.searchParams).subscribe({
      next: (data: Vacuum[]) => {
        this.vacuums = data;
      },
      error: (error) => {
        console.error('Error fetching vacuums', error);
      }
    });
  }

  // Delete a vacuum
  deleteVacuum(id: number): void {
    this.vacuumService.removeVacuum(id).subscribe({
      next: () => {
        this.vacuums = this.vacuums.filter(v => v.id !== id);
      },
      error: (error) => {
        console.error('Error deleting vacuum', error);
      }
    });
  }

  // Start a vacuum
  startVacuum(id: number): void {
    this.vacuumService.startVacuum(id).subscribe({
      next: () => {
        console.log(`Vacuum ${id} started`);
      },
      error: (error) => {
        console.error('Error starting vacuum', error);
      }
    });
  }

  // Stop a vacuum
  stopVacuum(id: number): void {
    this.vacuumService.stopVacuum(id).subscribe({
      next: () => {
        console.log(`Vacuum ${id} stopped`);
      },
      error: (error) => {
        console.error('Error stopping vacuum', error);
      }
    });
  }

  // Discharge a vacuum
  dischargeVacuum(id: number): void {
    this.vacuumService.dischargeVacuum(id).subscribe({
      next: () => {
        console.log(`Vacuum ${id} discharging`);
      },
      error: (error) => {
        console.error('Error discharging vacuum', error);
      }
    });
  }
}
