import { Component, OnInit } from '@angular/core';
import { VacuumService } from '../../services/vacuum/vacuum.service';
import { ErrorMessage } from '../../services/vacuum/vacuum.model';
import {NgForOf} from "@angular/common";
import {TableComponent} from "../../shared/table/table.component";

@Component({
  selector: 'app-error-history',
  standalone: true,
  imports: [
    NgForOf,
    TableComponent
  ],
  templateUrl: './error-history.component.html',
  styleUrl: './error-history.component.css'
})
export class ErrorHistoryComponent implements OnInit {
  errorMessages: ErrorMessage[] = [];
  tableColumns: { key: keyof ErrorMessage; label: string }[] = [
    { key: 'date', label: 'Date' },
    { key: 'vacuumId', label: 'Vacuum ID' },
    { key: 'operation', label: 'Operation' },
    { key: 'message', label: 'Message' }
  ];

  constructor(private vacuumService: VacuumService) {}

  ngOnInit(): void {
    this.fetchErrorMessages();
  }

  fetchErrorMessages(): void {
    this.vacuumService.getErrorHistory().subscribe({
      next: (data: ErrorMessage[]) => {
        this.errorMessages = data;
      },
      error: (error) => {
        console.error('Error fetching error messages', error);
      }
    });
  }

}
