// user-list.component.ts

import {Component, OnInit, ViewChild} from '@angular/core';
import { UserService } from '../../../services/user/user.service';
import { User } from '../../../services/user/user.model';
import {AuthService} from "../../../services/auth.service";
import {NgClass, NgForOf, NgIf} from "@angular/common";
import {RouterLink} from "@angular/router";
import {TableComponent} from "../../../shared/table/table.component";
import {ButtonComponent} from "../../../shared/button/button.component";
import {UserAddComponent} from "../user-add/user-add.component";
import {UserEditComponent} from "../user-edit/user-edit.component";

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  imports: [
    NgIf,
    RouterLink,
    NgForOf,
    TableComponent,
    ButtonComponent,
    UserAddComponent,
    NgClass,
    UserEditComponent
  ],
  standalone: true
})
export class UserListComponent implements OnInit {
  users: User[] = [];
  tableColumns: { key: keyof User, label: string }[] = [
    { key: 'first_name', label: 'First Name' },
    { key: 'last_name', label: 'Last Name' },
    { key: 'email', label: 'Email' },
    { key: 'permissions', label: 'Permissions' }
  ];
  visibleModal: boolean = false;
  visibleModalEdit: boolean = false;
  selectedUserId: number | undefined;

  constructor(private userService: UserService, private authService: AuthService) {}

  ngOnInit(): void {
    this.userService.getUsers()
      .subscribe({
        next: (usersData) => {
          this.users = usersData.map(user => {
            return {
              id: user.id,
              first_name: user.firstName,
              last_name: user.lastName,
              email: user.email,
              username: user.username,
              password: user.password,
              permissions: [user.permissions], // Assuming permissions are stored as a JSON string
            };
          });
          console.log(this.users)
        },
        error: (error) => {
          console.error('Error fetching users:', error);
        }
      });
  }

  deleteUser(id: number | undefined) {
    if (id !== undefined && id !== null) {
      // this.userService.deleteUser(id)
      //   .subscribe({
      //     next: (msg) => {
      //       console.log(msg);
      //       this.users = this.users.filter(user => user.id !== id); // Remove user from list after deletion
      //     },
      //     error: (error) => {
      //       console.error('Error deleting user:', error);
      //       // Handle error and inform the user
      //     }
      //   });
    } else {
      console.error('User ID is undefined');
    }
  }

  editUser(id: number | undefined): void {
    if (id !== undefined) {
      this.selectedUserId = id;
      this.visibleModalEdit = true;
    } else {
      alert("Nepoznat id");
    }
  }

  hasRole(str: string) {
    return this.authService.hasRole(str.toUpperCase());
  }
}
