// user-edit.component.ts

import {Component, ElementRef, Input, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../../services/user/user.service';
import {User, UserRequest} from '../../../services/user/user.model';
import {FormsModule} from "@angular/forms";
import {ButtonComponent} from "../../../shared/button/button.component";
import {InputFieldComponent} from "../../../shared/input-field/input-field.component";
import {SelectComponent} from "../../../shared/select/select.component";

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  imports: [
    FormsModule,
    ButtonComponent,
    InputFieldComponent,
    SelectComponent
  ],
  standalone: true
})
export class UserEditComponent implements OnInit{

  editedUser: User = {
    first_name: '',
    last_name: '',
    email: '',
    username: '',
    password: '',
    permissions: []
  };
  @Input() userId: number | undefined; // Input property for user ID

  ngOnInit(): void {
    if (this.userId !== undefined) {
      this.loadUser(this.userId);
    }
  }

  constructor(private route: ActivatedRoute, private userService: UserService, private router: Router,private el: ElementRef) {}

  loadUser(userId: number): void {
    this.userService.findUser(userId).subscribe({
      next: (user) => {
        this.editedUser.first_name = user.firstName;
        this.editedUser.last_name = user.lastName;
        this.editedUser.username = user.username;
        this.editedUser.email = user.email;
        this.editedUser.password = user.password;
        this.editedUser.permissions = user.permissions
          .replace(/^\[|\]$/g, '')    // Remove leading and trailing square brackets
          .replace(/'/g, '')          // Remove single quotes
          .split(',')                 // Split by comma
          .map(permission => permission.trim()); // Trim any extra spaces
        console.log('User found successfully:', user);
      },
      error: (error) => {
        console.error('Error updating user:', error);
      }
    });
  }

  updateUser(): void {
    if (this.userId !== undefined) {
      let user: UserRequest = {
        id: this.editedUser.id,
        firstName: this.editedUser.first_name,
        lastName: this.editedUser.last_name,
        email: this.editedUser.email,
        username: this.editedUser.username,
        password: this.editedUser.password,
        permissions: this.editedUser.permissions ? this.editedUser.permissions.join(', ') : ''
      };

      this.userService.editUser(this.userId, user)
        .subscribe({
          next: (user) => {
            console.log('User updated successfully:', user);
            this.router.navigate(['/users']).then();
          },
          error: (error) => {
            console.error('Error updating user:', error);
          }
        });
    }
  }
}
