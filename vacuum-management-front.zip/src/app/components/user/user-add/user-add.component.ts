// user-add.component.ts

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../../services/user/user.service';
import {User, UserRequest} from '../../../services/user/user.model';
import {FormsModule} from "@angular/forms";
import {InputFieldComponent} from "../../../shared/input-field/input-field.component";
import {ButtonComponent} from "../../../shared/button/button.component";
import {SelectComponent} from "../../../shared/select/select.component";

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  imports: [
    FormsModule,
    InputFieldComponent,
    ButtonComponent,
    SelectComponent
  ],
  standalone: true
})
export class UserAddComponent {
  newUser: User = {
    first_name: '',
    last_name: '',
    username: '',
    email: '',
    password: 'asd',
    permissions: []
  };

  constructor(private userService: UserService, private router: Router) {}

  addUser(): void {
    let user: UserRequest = {
      id: this.newUser.id,
      firstName: this.newUser.first_name,
      lastName: this.newUser.last_name,
      email: this.newUser.email,
      username: this.newUser.username,
      password: this.newUser.password,
      permissions: this.newUser.permissions ? this.newUser.permissions.join(', ') : ''
    };

    this.userService.addUser(user)
      .subscribe({
        next: (user) => {
          console.log('User added successfully:', user);
          this.router.navigate(['/users']).then();
        },
        error: (error) => {
          console.error('Error adding user:', error);
        }
      });
  }
}
