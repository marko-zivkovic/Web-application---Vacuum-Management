import { Component } from '@angular/core';
import { VacuumService } from '../../services/vacuum/vacuum.service';
import { Router } from '@angular/router';
import {FormsModule} from "@angular/forms";
import {InputFieldComponent} from "../../shared/input-field/input-field.component";
import {ButtonComponent} from "../../shared/button/button.component";


@Component({
  selector: 'app-add-vacuum',
  standalone: true,
  imports: [
    FormsModule,
    InputFieldComponent,
    ButtonComponent
  ],
  templateUrl: './add-vacuum.component.html',
  styleUrl: './add-vacuum.component.css'
})
export class AddVacuumComponent {
  vacuum = {
    name: '',
    type: '',
    description: ''
  };

  constructor(private vacuumService: VacuumService, private router: Router) {}

  addVacuum(): void {
    this.vacuumService.addVacuum(this.vacuum).subscribe(() => {
      this.router.navigate(['/search-vacuums']);
    });
  }
}
