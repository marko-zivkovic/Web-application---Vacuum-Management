import { Routes } from '@angular/router';
import { SearchVacuumsComponent } from './components/search-vacuums/search-vacuums.component';
import { AddVacuumComponent } from './components/add-vacuum/add-vacuum.component';
import { ErrorHistoryComponent } from './components/error-history/error-history.component';
import { AuthGuard } from './guards/auth.guard';
import { PermissionsGuard } from './guards/permissions.guard';
import {UserEditComponent} from "./components/user/user-edit/user-edit.component";
import {UserAddComponent} from "./components/user/user-add/user-add.component";
import {UserListComponent} from "./components/user/user-list/user-list.component";
import {LoginComponent} from "./components/auth/login/login.component";

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'users',
    component: UserListComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: { role: 'can_read_users' }
  },
  {
    path: 'users/add',
    component: UserAddComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: { role: 'can_create_users' }
  },
  {
    path: 'users/edit/:id',
    component: UserEditComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: { role: 'can_edit_users' }
  },
  {
    path: 'search-vacuums',
    component: SearchVacuumsComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: { permission: 'can_search_vacuum' }
  },
  {
    path: 'add-vacuum',
    component: AddVacuumComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: { permission: 'can_add_vacuum' }
  },
  {
    path: 'error-history',
    component: ErrorHistoryComponent,
    canActivate: [AuthGuard, PermissionsGuard],
    data: { permission: 'can_view_error_history' }
  },
  // { path: '', redirectTo: '/vacuum-search', pathMatch: 'full' },
  // { path: '**', redirectTo: '/vacuum-search' }
];
