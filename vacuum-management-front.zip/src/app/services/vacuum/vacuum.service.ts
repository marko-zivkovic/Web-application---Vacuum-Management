import { Injectable } from '@angular/core';
import axios, { AxiosRequestConfig } from 'axios';
import { Observable } from 'rxjs';
import { from } from 'rxjs';
import { Vacuum, ErrorMessage } from './vacuum.model';

@Injectable({
  providedIn: 'root'
})
export class VacuumService {
  private baseUrl = 'http://localhost:8080/api/vacuum';  // Update with actual backend URL

  constructor() {}

  private getHeaders(): any {
    const token = localStorage.getItem('token');
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    };
  }

  searchVacuums(params?: any): Observable<Vacuum[]> {
    const headers = this.getHeaders();
    let url = `${this.baseUrl}/search`;

    // Build query string for params
    const searchParams = new URLSearchParams();
    if (params) {
      if (params.name) {
        searchParams.set('name', params.name);
      }
      if (params.status && params.status.length) {
        params.status.forEach((status: string) => {
          searchParams.append('status', status);
        });
      }
      if (params.dateFrom) {
        searchParams.set('dateFrom', params.dateFrom);
      }
      if (params.dateTo) {
        searchParams.set('dateTo', params.dateTo);
      }
    }

    url += `?${searchParams.toString()}`;

    return from(axios.get<Vacuum[]>(url, { headers }).then(response => response.data));
  }

  addVacuum(vacuum: Partial<Vacuum>): Observable<Vacuum> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };

    return from(axios.post<Vacuum>(`${this.baseUrl}/add`, vacuum, config).then(response => response.data));
  }

  removeVacuum(vacuumId: number): Observable<void> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };

    return from(axios.delete<void>(`${this.baseUrl}/delete/${vacuumId}`, config).then(response => response.data));
  }

  startVacuum(vacuumId: number): Observable<void> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };

    return from(axios.put<void>(`${this.baseUrl}/start/${vacuumId}`, {}, config).then(response => response.data));
  }

  stopVacuum(vacuumId: number): Observable<void> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };

    return from(axios.put<void>(`${this.baseUrl}/stop/${vacuumId}`, {}, config).then(response => response.data));
  }

  dischargeVacuum(vacuumId: number): Observable<void> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };

    return from(axios.put<void>(`${this.baseUrl}/discharge/${vacuumId}`, {}, config).then(response => response.data));
  }

  getErrorHistory(): Observable<ErrorMessage[]> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };

    return from(axios.get<ErrorMessage[]>(`errors/${this.baseUrl}`, config).then(response => response.data));
  }
}
