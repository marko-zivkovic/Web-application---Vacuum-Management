export interface Vacuum {
  id: number;
  name: string;
  type: string;
  description: string;
  status: 'ON' | 'OFF' | 'DISCHARGING';
  addedBy: number;
  active: boolean;
  created_at: Date;
}

export interface ErrorMessage {
  date: Date;
  vacuumId: number;
  operation: 'START' | 'STOP' | 'DISCHARGE';
  message: string;
}
