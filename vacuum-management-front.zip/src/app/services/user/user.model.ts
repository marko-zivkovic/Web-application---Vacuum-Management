export interface User {
  id?: number;
  first_name?: string;
  last_name?: string;
  email?: string;
  username?: string;
  password?: string;
  permissions: string[];
}
export interface UserRequest {
  id?: number;
  firstName?: string;
  lastName?: string;
  email?: string;
  username?: string;
  password?: string;
  permissions: string;
}
