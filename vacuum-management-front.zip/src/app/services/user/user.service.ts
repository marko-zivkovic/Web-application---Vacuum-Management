import { Injectable } from '@angular/core';
import axios, { AxiosRequestConfig } from 'axios';
import { Observable, from } from 'rxjs';
import { User, UserRequest } from './user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:8080/api/users';

  constructor() {}

  private getHeaders(): any {
    const token = localStorage.getItem('token');
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    };
  }

  getUsers(): Observable<UserRequest[]> {
    const headers = this.getHeaders();
    return from(
      axios.get<UserRequest[]>(`${this.apiUrl}`, { headers })
        .then(response => response.data)
    );
  }

  addUser(user: UserRequest): Observable<User> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };
    return from(
      axios.post<User>(`http://localhost:8080/api/auth/register`, user, config)
        .then(response => response.data)
    );
  }

  editUser(userId: number, user: UserRequest): Observable<User> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };
    return from(
      axios.put<User>(`${this.apiUrl}/update/${userId}`, user, config)
        .then(response => response.data)
    );
  }

  deleteUser(userId: number): Observable<void> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };
    return from(
      axios.delete<void>(`${this.apiUrl}/users/${userId}`, config)
        .then(response => response.data)
    );
  }

  findUser(userId: number): Observable<UserRequest> {
    const headers = this.getHeaders();
    const config: AxiosRequestConfig = { headers };
    return from(
      axios.get<UserRequest>(`${this.apiUrl}/${userId}`, config)
        .then(response => response.data)
    );
  }
}
