import { Injectable } from '@angular/core';
import axios, { AxiosRequestConfig } from 'axios';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:8080/api';
  private loggedInSubject = new BehaviorSubject<boolean>(this.isTokenValid());
  public isLoggedIn$ = this.loggedInSubject.asObservable();
  private userPermissions: string[] = [];

  constructor() {
    this.loadPermissionsFromToken(); // Load permissions on service initialization
  }

  login(username: string, password: string): Observable<string> {
    return new Observable(observer => {
      axios.post(`${this.apiUrl}/auth/login`, { username, password })
        .then(response => {
          const token = response.data.access_token;
          localStorage.setItem('token', token);
          this.loggedInSubject.next(true);
          observer.next(token);
          observer.complete();
        })
        .catch(error => {
          observer.error(error);
        });
    });
  }

  logout(): Observable<void> {
    const token = localStorage.getItem('token');

    if (!token) {
      this.loggedInSubject.next(false);
      return of(undefined);
    }

    const config: AxiosRequestConfig = {
      headers: { 'Content-Type': 'text/plain' },
      responseType: 'text' // Expect plain text response
    };

    return new Observable(observer => {
      axios.post(`${this.apiUrl}/auth/logout`, token, config)
        .then(() => {
          localStorage.removeItem('token');
          this.loggedInSubject.next(false);
          observer.next();
          observer.complete();
        })
        .catch(error => {
          observer.error(error);
        });
    });
  }

  hasRole(required: string): boolean {
    return this.userPermissions.includes(required);
  }

  private setUserPermissions(token: string): void {
    const decoded = this.parseJwt(token);

    if (typeof decoded.permissions === 'string') {
      this.userPermissions = decoded.permissions.replace('[','').replace(']','').split(',').map((permission: string) => permission.trim());
    } else if (Array.isArray(decoded.permissions)) {
      this.userPermissions = decoded.permissions;
    }

    // Optionally save permissions in localStorage for quick access
    localStorage.setItem('permissions', JSON.stringify(this.userPermissions));
  }

  private loadPermissionsFromToken(): void {
    const token = localStorage.getItem('token');

    if (token) {
      this.setUserPermissions(token);
    }
  }

  private isTokenValid(): boolean {
    const token = localStorage.getItem('token');
    return !!token;
  }

  private parseJwt(token: string): any {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
  }


}
