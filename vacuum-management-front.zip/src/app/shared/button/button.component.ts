import {Component, Input} from '@angular/core';
import {NgClass} from "@angular/common";

@Component({
  selector: 'app-button',
  standalone: true,
  imports: [
    NgClass
  ],
  templateUrl: './button.component.html',
  styleUrl: './button.component.css'
})
export class ButtonComponent {
  @Input() type: 'button' | 'submit' | 'reset' = 'button';
  @Input() text: string = '';
  @Input() color_bg: string = 'zinc';
  @Input() color_fg: string = 'white';
  @Input() disabled: boolean = false;
  @Input() extraClasses: string = ''; // Added to allow additional classes

  get buttonClasses(): string {
    if (this.color_bg === 'white'){
      return `py-2.5 px-5 ms-3 text-sm font-medium text-gray-900 focus:outline-none bg-white rounded-lg border border-gray-200 hover:bg-gray-100 hover:text-gray-700 focus:z-10 focus:ring-4 focus:ring-gray-100 dark:focus:ring-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-600 dark:hover:text-white dark:hover:bg-gray-700`;
    }
    return `flex w-full justify-center rounded-md bg-${this.color_bg}-600 px-3 py-1.5 text-sm font-semibold leading-6 text-${this.color_fg} shadow-sm hover:bg-${this.color_bg}-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-${this.color_bg}-600 ${this.extraClasses}`;
  }
}
