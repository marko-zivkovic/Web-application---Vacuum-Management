import {Component, Input} from '@angular/core';
import {NgForOf, NgIf} from "@angular/common";

@Component({
  selector: 'app-table',
  standalone: true,
  imports: [
    NgIf,
    NgForOf
  ],
  templateUrl: './table.component.html',
  styleUrl: './table.component.css'
})
export class TableComponent<T> {
  @Input() data: T[] = [];
  @Input() columns: { key: keyof T, label: string }[] = [];
  @Input() actions: {
    label: string;
    handler: (item: T) => void;
    visible: (item: T) => boolean;
  }[] = [];
  @Input() roleCheck: (role: string) => boolean = () => true;

  // Method to determine if an action is visible
  isActionVisible(action: { label: string; handler: (item: T) => void; visible: (item: T) => boolean }, item: T): boolean {
    return action.visible(item);
  }
}
