import {Component, EventEmitter, Input, Output} from '@angular/core';
import {NgForOf, NgIf} from "@angular/common";
import {FormsModule} from "@angular/forms";

@Component({
  selector: 'app-select',
  standalone: true,
  imports: [
    NgForOf,
    FormsModule,
    NgIf
  ],
  templateUrl: './select.component.html',
  styleUrl: './select.component.css'
})
export class SelectComponent {
  @Input() options: { value: string; label: string }[] = [];
  @Input() value: string[] = [];
  @Input() placeholder: string = 'Select...';
  @Output() valueChange = new EventEmitter<string[]>();
  @Input() label: string = '';

  isDropdownOpen = false;

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  selectOption(option: { value: string; label: string }) {
    if (this.value.includes(option.value)) {
      this.value = this.value.filter(val => val !== option.value);
    } else {
      this.value = [...this.value, option.value];
    }
    this.valueChange.emit(this.value);
  }

  isSelected(option: { value: string; label: string }): boolean {
    return this.value.includes(option.value);
  }

  get displayValue(): string {
    return this.value.length ? this.options
      .filter(option => this.value.includes(option.value))
      .map(option => option.label)
      .join(', ') : this.placeholder;
  }

}
