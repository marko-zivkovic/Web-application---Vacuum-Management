import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';


import { routes } from './app.routes';
import {HttpHandlerFn, HttpInterceptorFn, HttpRequest, provideHttpClient, withInterceptors} from "@angular/common/http";

export const authenticationInterceptor: HttpInterceptorFn = (req: HttpRequest<unknown>, next:
  HttpHandlerFn) => {
  const modifiedReq = req.clone({
    headers: req.headers.set('Authorization', `Bearer ${localStorage.getItem('token')}`),
  });

  return next(modifiedReq);
};

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(withInterceptors([authenticationInterceptor])),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes)
  ]
};
