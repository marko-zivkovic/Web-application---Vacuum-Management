package com.blank.vacuum.service;

import com.blank.vacuum.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    List<User> getAllUsers();

    Optional<User> getUserById(Integer id);

    User saveUser(User user);

    Optional<User> updateUser(Integer id, User userDetails);

    boolean deleteUser(Integer id);
}
