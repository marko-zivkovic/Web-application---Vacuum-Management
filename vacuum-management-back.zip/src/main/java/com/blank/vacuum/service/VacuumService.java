package com.blank.vacuum.service;

import com.blank.vacuum.dto.VacuumDto;

import java.time.LocalDateTime;
import java.util.List;

public interface VacuumService {
    VacuumDto createVacuum(VacuumDto vacuumDto, Long userId);
    void deleteVacuum(Long id);
    List<VacuumDto> searchVacuums(String name, List<String> status, String dateFrom, String dateTo);
    void startVacuum(Long id);
    void stopVacuum(Long id);
    void dischargeVacuum(Long id);
    void scheduleStartVacuum(Long id, LocalDateTime startTime);
    void scheduleStopVacuum(Long id, LocalDateTime startTime);
    void scheduleDischargeVacuum(Long id, LocalDateTime startTime);
}
