package com.blank.vacuum.service.impl;

import com.blank.vacuum.dto.VacuumDto;
import com.blank.vacuum.entity.ErrorMessage;
import com.blank.vacuum.entity.Vacuum;
import com.blank.vacuum.helper.enums;
import com.blank.vacuum.repository.ErrorMessageRepository;
import com.blank.vacuum.repository.VacuumRepository;
import com.blank.vacuum.service.VacuumService;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class VacuumServiceImpl implements VacuumService {

    private VacuumRepository vacuumRepository;
    private ErrorMessageRepository errorMessageRepository;
    private ThreadPoolTaskScheduler taskScheduler;

    @Override
    public VacuumDto createVacuum(VacuumDto vacuumDto, Long userId) {
        if (vacuumDto == null) {
            throw new IllegalArgumentException("Error parsing data!");
        }

        if (userId == null) {
            throw new IllegalArgumentException("User ID must not be null");
        }

        if (vacuumDto.getName() == null || vacuumDto.getName().isEmpty()) {
            throw new IllegalArgumentException("Name must not be empty");
        }

        Vacuum vacuum = new Vacuum(userId);
        vacuum.setName(vacuumDto.getName());
        vacuum.setType(vacuumDto.getType() != null ? vacuumDto.getType() : "Default Type");
        vacuum.setDescription(vacuumDto.getDescription() != null ? vacuumDto.getDescription() : "No description");
        vacuum.setStatus(enums.Status.OFF);
        try {
            Vacuum createdVacuum = vacuumRepository.save(vacuum);
            return mapToDto(createdVacuum);
        } catch (Exception e) {
            saveError(0L,"Creating",e.getMessage());
            throw new RuntimeException("Error creating vacuum", e);
        }
    }

    @Override
    public void deleteVacuum(Long id) {
        Optional<Vacuum> vacuumOpt = vacuumRepository.findById(Math.toIntExact(id));
        if (vacuumOpt.isPresent()) {
            Vacuum vacuum = vacuumOpt.get();

            // Check if the vacuum is in the STOPPED state
            if (vacuum.getStatus() != enums.Status.OFF) {
                throw new RuntimeException("Vacuum must be in STOPPED state to be removed.");
            }

            // Mark the vacuum as removed
            vacuum.setRemoved(true);  // Assuming you have a 'removed' field in your entity
            vacuumRepository.save(vacuum);
        } else {
            throw new RuntimeException("Vacuum not found with id " + id);
        }
    }

    @Override
    public List<VacuumDto> searchVacuums(String name, List<String> status, String dateFrom, String dateTo) {
        // Fetch all vacuums (consider implementing a more efficient query if possible)
        List<Vacuum> vacuums = vacuumRepository.findAll();

        // Convert date strings to LocalDate objects
        LocalDate parsedDateFrom = null;
        LocalDate parsedDateTo = null;

        try {
            if (dateFrom != null && !dateFrom.isEmpty()) {
                parsedDateFrom = LocalDate.parse(dateFrom);
            }
            if (dateTo != null && !dateTo.isEmpty()) {
                parsedDateTo = LocalDate.parse(dateTo);
            }
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Invalid date format. Use YYYY-MM-DD.");
        }

        // Filter vacuums based on criteria
        LocalDate finalParsedDateFrom = parsedDateFrom;
        LocalDate finalParsedDateTo = parsedDateTo;
        List<Vacuum> filteredVacuums = vacuums.stream()
                .filter(vacuum -> (name == null || name.isEmpty() || vacuum.getName().contains(name)))
                .filter(vacuum -> (status == null || status.isEmpty() || status.contains(vacuum.getStatus().name())))
                .filter(vacuum -> (finalParsedDateFrom == null || vacuum.getCreatedAt().isAfter(finalParsedDateFrom.minusDays(1)))
                        && (finalParsedDateTo == null || vacuum.getCreatedAt().isBefore(finalParsedDateTo.plusDays(1))))
                .toList();

        // Map to DTOs
        return filteredVacuums.stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }


    @Override
    public void startVacuum(Long id) {
        Optional<Vacuum> vacuumOpt = vacuumRepository.findById(Math.toIntExact(id));

        if (vacuumOpt.isPresent()) {
            Vacuum vacuum = vacuumOpt.get();

            // Ensure the vacuum can only be started if it is in the STOPPED state
            if (!vacuum.getStatus().equals(enums.Status.OFF)) {
                throw new RuntimeException("Vacuum cannot be started unless it is in the STOPPED state.");
            }

            // Set the vacuum status to ON (indicating it's in the process of starting)
            vacuum.setStatus(enums.Status.ON);
            vacuumRepository.save(vacuum);

            // Implement background task logic with a delay to simulate the start process
            new Thread(() -> {
                try {
                    // Simulate time delay (15+ seconds with possible deviation)
                    Thread.sleep(15000 + (long) (Math.random() * 5000)); // 15 to 20 seconds delay

                    // After the delay, set the vacuum status to RUNNING
                    vacuum.setStatus(enums.Status.ON);
                    vacuumRepository.save(vacuum);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Vacuum start process was interrupted.", e);
                }
            }).start();

        } else {
            throw new RuntimeException("Vacuum not found with id " + id);
        }
    }

    @Override
    public void stopVacuum(Long id) {
        Optional<Vacuum> vacuumOpt = vacuumRepository.findById(Math.toIntExact(id));
        if (vacuumOpt.isPresent()) {
            Vacuum vacuum = vacuumOpt.get();

            // Check if the vacuum is in the RUNNING state
            if (vacuum.getStatus() != enums.Status.ON) {
                throw new RuntimeException("Vacuum must be in RUNNING state to be stopped.");
            }

            // Background task to handle the stopping process
            new Thread(() -> {
                try {
                    // Simulate the stopping process with time deviation
                    Thread.sleep(calculateTimeWithDeviation(15000)); // Sleep for 15+ seconds

                    // Set the vacuum to STOPPED state after the delay
                    vacuum.setStatus(enums.Status.OFF);
                    vacuumRepository.save(vacuum);

                } catch (InterruptedException e) {
                    throw new RuntimeException("Stop process interrupted for vacuum with id " + id, e);
                }
            }).start();

        } else {
            throw new RuntimeException("Vacuum not found with id " + id);
        }
    }

    @Override
    public void dischargeVacuum(Long id) {
        Optional<Vacuum> vacuumOpt = vacuumRepository.findById(Math.toIntExact(id));
        if (vacuumOpt.isPresent()) {
            Vacuum vacuum = vacuumOpt.get();

            // Check if the vacuum is in the STOPPED state
            if (vacuum.getStatus() != enums.Status.OFF) {
                throw new RuntimeException("Vacuum must be in STOPPED state to be discharged.");
            }

            // Background task to handle the discharge process
            new Thread(() -> {
                try {
                    // First half of the discharge process: set to DISCHARGING
                    Thread.sleep(calculateTimeWithDeviation(15000)); // Sleep for 15+ seconds
                    vacuum.setStatus(enums.Status.DISCHARGING);
                    vacuumRepository.save(vacuum);

                    // Second half of the discharge process: set to STOPPED
                    Thread.sleep(calculateTimeWithDeviation(15000)); // Sleep for another 15+ seconds
                    vacuum.setStatus(enums.Status.OFF);
                    vacuumRepository.save(vacuum);

                    // Check if this is the third cycle
                    int dischargeCount = vacuum.getDischargeCount() + 1;
                    vacuum.setDischargeCount(dischargeCount);

                } catch (InterruptedException e) {
                    throw new RuntimeException("Discharge process interrupted for vacuum with id " + id, e);
                }
            }).start();

        } else {
            throw new RuntimeException("Vacuum not found with id " + id);
        }
    }

    @Override
    public void scheduleStartVacuum(Long id, LocalDateTime startTime) {
        Date startDate = Date.from(startTime.atZone(ZoneId.systemDefault()).toInstant());

        taskScheduler.schedule(() -> {
            try {
                startVacuum(id);
            } catch (Exception e) {
                saveError(id, "START", e.getMessage());
            }
        }, startDate);
    }

    @Override
    public void scheduleStopVacuum(Long id, LocalDateTime stopTime) {
        Date stopDate = Date.from(stopTime.atZone(ZoneId.systemDefault()).toInstant());

        taskScheduler.schedule(() -> {
            try {
                stopVacuum(id);
            } catch (Exception e) {
                saveError(id, "STOP", e.getMessage());
            }
        }, stopDate);
    }

    @Override
    public void scheduleDischargeVacuum(Long id, LocalDateTime dischargeTime) {
        Date dischargeDate = Date.from(dischargeTime.atZone(ZoneId.systemDefault()).toInstant());

        taskScheduler.schedule(() -> {
            try {
                dischargeVacuum(id);
            } catch (Exception e) {
                saveError(id, "DISCHARGE", e.getMessage());
            }
        }, dischargeDate);
    }

    // Method to calculate time with deviation
    private long calculateTimeWithDeviation(long baseTime) {
        // Implement logic for deviation here (e.g., +/- 2 seconds)
        return baseTime + (long)(Math.random() * 4000 - 2000); // Example deviation: ±2 seconds
    }

    private VacuumDto mapToDto(Vacuum vacuum) {
        return new VacuumDto(
                vacuum.getId(),
                vacuum.getName(),
                vacuum.getType(),
                vacuum.getDescription(),
                vacuum.getActive(),
                vacuum.getStatus()
        );
    }

    // Helper method to save error messages
    private void saveError(Long vacuumId, String operation, String message) {
        ErrorMessage errorMessage = new ErrorMessage();
        errorMessage.setVacuumId(vacuumId);
        errorMessage.setOperation(operation);
        errorMessage.setMessage(message);
        errorMessageRepository.save(errorMessage);
    }

}
