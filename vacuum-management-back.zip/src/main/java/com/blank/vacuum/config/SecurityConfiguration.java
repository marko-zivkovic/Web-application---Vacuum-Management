package com.blank.vacuum.config;

import com.blank.vacuum.config.filter.JwtAuthenticationFilter;
import com.blank.vacuum.helper.enums;
import com.blank.vacuum.service.impl.UserDetailsServiceImp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration {

  private final UserDetailsServiceImp userDetailsServiceImp;

  private final JwtAuthenticationFilter jwtAuthenticationFilter;

  public SecurityConfiguration(UserDetailsServiceImp userDetailsServiceImp,
                        JwtAuthenticationFilter jwtAuthenticationFilter) {
    this.userDetailsServiceImp = userDetailsServiceImp;
    this.jwtAuthenticationFilter = jwtAuthenticationFilter;
  }

  @Bean
  public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

    return http
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(
                    req -> req
                            .requestMatchers("/api/auth/login","/api/auth/logout", "/api/errorHistory").permitAll()
                            .requestMatchers("/api/users").hasAuthority(String.valueOf(enums.Permission.CAN_READ_USERS))
                            .requestMatchers("/api/users/delete/**").hasAuthority(String.valueOf(enums.Permission.CAN_DELETE_USERS))
                            .requestMatchers("/api/users/save").hasAuthority(String.valueOf(enums.Permission.CAN_CREATE_USERS))
                            .requestMatchers("/api/users/update/**","/api/auth/register").hasAuthority(String.valueOf(enums.Permission.CAN_UPDATE_USERS))
                            .requestMatchers("/api/vacuum/start").hasAuthority(String.valueOf(enums.Permission.CAN_START_VACUUM))
                            .requestMatchers("/api/vacuum/add").hasAuthority(String.valueOf(enums.Permission.CAN_ADD_VACUUM))
                            .requestMatchers("/api/vacuum/delete","/api/vacuum/delete/**").hasAuthority(String.valueOf(enums.Permission.CAN_REMOVE_VACUUMS))
                            .requestMatchers("/api/vacuum/discharge").hasAuthority(String.valueOf(enums.Permission.CAN_DISCHARGE_VACUUM))
                            .requestMatchers("/api/vacuum/search").hasAuthority(String.valueOf(enums.Permission.CAN_SEARCH_VACUUM))
                            .anyRequest()
                            .authenticated()
            ).userDetailsService(userDetailsServiceImp)
            .sessionManagement(session->session
                    .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
            .exceptionHandling(
                    e->e.accessDeniedHandler(
                                    (request, response, accessDeniedException)->response.setStatus(403)
                            )
                            .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
            .build();

  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return new BCryptPasswordEncoder();
  }

  @Bean
  public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
    return configuration.getAuthenticationManager();
  }


}