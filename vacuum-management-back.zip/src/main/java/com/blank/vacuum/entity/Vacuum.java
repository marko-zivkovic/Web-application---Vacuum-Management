package com.blank.vacuum.entity;

import com.blank.vacuum.helper.enums;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "vacuums")
@Entity
public class Vacuum {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String type;
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false) // Make sure status is not null
    private enums.Status status;

    @Column(name = "user_id")
    private Long userId; // Use Long if it is referencing another entity

    @Column(nullable = false)
    private Boolean active = true;

    @Column(name = "created_at")
    private LocalDate createdAt = LocalDate.now();

    @Column(name = "discharge_count", nullable = false)
    private int dischargeCount = 0; // Default value to 0

    // Constructor for creating a vacuum with a specific user ID
    public Vacuum(Long userId) {
        this.userId = userId;
    }

    // Method to mark the vacuum as removed
    public void setRemoved(boolean removed) {
        this.active = removed;
    }

    public boolean isRemoved() {
        return active;
    }
}
