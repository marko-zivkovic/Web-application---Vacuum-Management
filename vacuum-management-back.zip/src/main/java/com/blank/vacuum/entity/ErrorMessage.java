package com.blank.vacuum.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "error_messages")
public class ErrorMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "vacuum_id", nullable = false)
    private Long vacuumId;
    @Column(name = "user_id")
    private Long userId;

    @Column(nullable = false)
    private String operation;

    @Column(nullable = false)
    private String message;

    @Column(name = "error_date", nullable = false)
    private LocalDateTime errorDate = LocalDateTime.now();
}
