package com.blank.vacuum.repository;

import com.blank.vacuum.entity.Vacuum;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VacuumRepository extends JpaRepository<Vacuum, Integer> {
}
