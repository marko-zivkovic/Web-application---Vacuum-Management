package com.blank.vacuum.dto;

import com.blank.vacuum.helper.enums;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VacuumDto {
    private Long id;
    private String name;
    private String type;
    private String description;
    private Boolean active;
    private enums.Status status;
}
