package com.blank.vacuum.dto.mapper;

import com.blank.vacuum.dto.VacuumDto;
import com.blank.vacuum.entity.Vacuum;

public class VacuumMapper {
//    public static Vacuum mapToVacuum(VacuumDto vacuumDto){
//        Vacuum vacuum;
//        vacuum = new Vacuum(
//                vacuumDto.getId(),
//                vacuumDto.getStatus(),
//                1L,
//                vacuumDto.getActive()
//        );
//        return vacuum;
//    }
//
//    public static VacuumDto mapToVacuumDto(Vacuum vacuum){
//        VacuumDto vacuumDto;
//        vacuumDto = new VacuumDto(
//                vacuum.getId(),
//                vacuum.getStatus().toString(),
//                vacuum.getActive()
//                );
//        return vacuumDto;
//    }
}
