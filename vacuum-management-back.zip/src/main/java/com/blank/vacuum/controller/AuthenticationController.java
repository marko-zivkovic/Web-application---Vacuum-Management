package com.blank.vacuum.controller;

import com.blank.vacuum.dto.responses.AuthenticationResponse;
import com.blank.vacuum.entity.User;

import com.blank.vacuum.service.AuthenticationService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthenticationController {

  private final AuthenticationService authService;

  @PostMapping("/register")
  public ResponseEntity<AuthenticationResponse> register(
          @RequestBody User request
  ) {
    return ResponseEntity.ok(authService.register(request));
  }

  @PostMapping("/login")
  public ResponseEntity<AuthenticationResponse> login(
          @RequestBody User request
  ) {
    return ResponseEntity.ok(authService.authenticate(request));
  }

  @PostMapping("/logout")
  public ResponseEntity<String> logout(@RequestBody String token) {
    authService.logout(token);
    return ResponseEntity.ok("success");
  }

  @PostMapping("/refresh_token")
  public ResponseEntity refreshToken(HttpServletRequest request) {
    return authService.refreshToken(request);
  }

}
