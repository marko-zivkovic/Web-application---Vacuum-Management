package com.blank.vacuum.controller;

import com.blank.vacuum.dto.VacuumDto;
import com.blank.vacuum.service.VacuumService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/api/vacuum")
public class VacuumController {

    private VacuumService vacuumService;

    // Search Vacuums
    @GetMapping("/search")
    public ResponseEntity<List<VacuumDto>> searchVacuums(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) List<String> status,
            @RequestParam(required = false) String dateFrom,
            @RequestParam(required = false) String dateTo) {
        List<VacuumDto> vacuums = vacuumService.searchVacuums(name, status, dateFrom, dateTo);
        return ResponseEntity.ok(vacuums);
    }

    // Add a New Vacuum
    @PostMapping("/add")
    public ResponseEntity<VacuumDto> addVacuum(
            @RequestBody VacuumDto vacuum,
            @RequestAttribute("userId") String userId) {

        VacuumDto newVacuum = vacuumService.createVacuum(vacuum, Long.valueOf(userId));
        return ResponseEntity.ok(newVacuum);
    }


    // Start a Vacuum
    @PutMapping("/start/{id}")
    public ResponseEntity<String> startVacuum(@PathVariable Long id) {
        vacuumService.startVacuum(id);
        System.out.println("start");
        return ResponseEntity.ok("Vacuum start operation initiated.");
    }

    // Stop a Vacuum
    @PutMapping("/stop/{id}")
    public ResponseEntity<String> stopVacuum(@PathVariable Long id) {
        vacuumService.stopVacuum(id);
        return ResponseEntity.ok("Vacuum stop operation initiated.");
    }

    // Discharge a Vacuum
    @PutMapping("/discharge/{id}")
    public ResponseEntity<String> dischargeVacuum(@PathVariable Long id) {
        vacuumService.dischargeVacuum(id);
        return ResponseEntity.ok("Vacuum discharge operation initiated.");
    }

    // Delete a Vacuum
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteVacuum(@PathVariable Long id) {
        vacuumService.deleteVacuum(id);
        return ResponseEntity.ok("Vacuum deleted successfully.");
    }

    @PostMapping("/scheduleStart")
    public String scheduleStartVacuum(@RequestParam Long id, @RequestParam String startTime) {
        LocalDateTime startDateTime = LocalDateTime.parse(startTime); // Assumes ISO_LOCAL_DATE_TIME format
        vacuumService.scheduleStartVacuum(id, startDateTime);
        return "Vacuum start scheduled for " + startDateTime;
    }

    @PostMapping("/scheduleStop")
    public String scheduleStopVacuum(@RequestParam Long id, @RequestParam String stopTime) {
        LocalDateTime stopDateTime = LocalDateTime.parse(stopTime); // Assumes ISO_LOCAL_DATE_TIME format
        vacuumService.scheduleStopVacuum(id, stopDateTime);
        return "Vacuum stop scheduled for " + stopDateTime;
    }

    @PostMapping("/scheduleDischarge")
    public String scheduleDischargeVacuum(@RequestParam Long id, @RequestParam String dischargeTime) {
        LocalDateTime dischargeDateTime = LocalDateTime.parse(dischargeTime); // Assumes ISO_LOCAL_DATE_TIME format
        vacuumService.scheduleDischargeVacuum(id, dischargeDateTime);
        return "Vacuum discharge scheduled for " + dischargeDateTime;
    }
}
