package com.blank.vacuum.helper;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

public class enums {
    public enum Status {
        ON, OFF, DISCHARGING
    }

    @Getter
    @RequiredArgsConstructor
    public enum Permission {
        CAN_CREATE_USERS,
        CAN_READ_USERS,
        CAN_UPDATE_USERS,
        CAN_DELETE_USERS,
        CAN_SEARCH_VACUUM,
        CAN_START_VACUUM,
        CAN_STOP_VACUUM,
        CAN_DISCHARGE_VACUUM,
        CAN_ADD_VACUUM,
        CAN_REMOVE_VACUUMS
    }

}
