package com.blank.vacuum;

import com.blank.vacuum.dto.requests.RegisterRequest;
import com.blank.vacuum.entity.User;
import com.blank.vacuum.service.AuthenticationService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Set;

import static com.blank.vacuum.helper.enums.Permission.*;

@SpringBootApplication
public class VacuumApplication {

	public static void main(String[] args) {
		SpringApplication.run(VacuumApplication.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(
			AuthenticationService service
	) {
		return args -> {
			var admin = User.builder()
					.firstName("Admin")
					.lastName("Admin")
					.username("admin")
					.email("admin@mail.com")
					.password("asd")
					.address("Admin address")
					.permissions(Set.of(CAN_CREATE_USERS, CAN_READ_USERS,CAN_UPDATE_USERS,CAN_DELETE_USERS).toString())
					.build();
			System.out.println(service.register(admin));

//			var manager = RegisterRequest.builder()
//					.first_name("manager")
//					.last_name("manager")
//					.email("manager@mail.com")
//					.address("manager address")
//					.password("asd")
//					.permissions(CAN_READ_USERS.getPermission())
//					.build();
//			System.out.println(service.register(manager));
		};
	}

}
